#!/usr/bin/env python3
"""
step2_collect_results.py

Polls the batch submitted by step1 until it's done, then:
    - copies each original image into <output_folder>
    - writes the recovered capture date into EXIF DateTimeOriginal/Digitized
    - logs anything Claude couldn't read (or that errored) to needs_review.csv
      in the output folder, alongside the original crop for a quick manual look

Usage:
    python3 step2_collect_results.py <work_folder> <output_folder>

Pass --no-wait if you just want to check status once and exit instead of
polling until done.
"""

import os
import sys
import csv
import json
import time
import shutil
from pathlib import Path

import anthropic

from datestamp_common import get_all_corner_crops, parse_claude_date_reply, update_exif

POLL_SECONDS = 60


def save_review_crops(src_path, review_dir):
    """Save all 4 corner candidates so a human can quickly see which one has the stamp."""
    try:
        review_dir.mkdir(exist_ok=True)
        for corner, crop in get_all_corner_crops(src_path):
            crop.save(review_dir / f"{src_path.stem}_{corner}.png")
    except Exception:
        pass


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    no_wait = "--no-wait" in sys.argv

    if len(args) != 2:
        print("Usage: python3 step2_collect_results.py <work_folder> <output_folder> [--no-wait]")
        sys.exit(1)

    work_folder = Path(args[0]).resolve()
    output_folder = Path(args[1]).resolve()
    output_folder.mkdir(parents=True, exist_ok=True)
    review_dir = output_folder / "needs_review_crops"

    info_path = work_folder / "batch_info.json"
    if not info_path.exists():
        print(f"Error: {info_path} not found. Did you run step1_submit_batch.py first?")
        sys.exit(1)

    with open(info_path) as f:
        info = json.load(f)

    batch_id = info["batch_id"]
    custom_id_to_path = info["custom_id_to_path"]

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY is not set in your environment.")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)

    print(f"Checking batch {batch_id}...")
    while True:
        batch = client.messages.batches.retrieve(batch_id)
        counts = batch.request_counts
        print(f"  status={batch.processing_status}  "
              f"succeeded={counts.succeeded} errored={counts.errored} "
              f"processing={counts.processing} canceled={counts.canceled} expired={counts.expired}")
        if batch.processing_status == "ended":
            break
        if no_wait:
            print("Batch not finished yet. Re-run this script later (or drop --no-wait to keep polling).")
            sys.exit(0)
        time.sleep(POLL_SECONDS)

    print("Batch finished. Retrieving results...")

    success = fail = 0
    review_rows = []
    processed_rows = []  # (filename, year-month-day) for every successful write

    for entry in client.messages.batches.results(batch_id):
        custom_id = entry.custom_id
        src_path = Path(custom_id_to_path[custom_id])

        dest = output_folder / src_path.name
        counter = 1
        orig_dest = dest
        while dest.exists():
            dest = output_folder / f"{orig_dest.stem}_{counter:03d}{orig_dest.suffix}"
            counter += 1
        shutil.copyfile(src_path, dest)

        if entry.result.type != "succeeded":
            print(f"{src_path.name}: batch request {entry.result.type} -- flagged for review")
            review_rows.append((src_path.name, f"batch_{entry.result.type}"))
            fail += 1
            continue

        reply_text = ""
        for block in entry.result.message.content:
            if getattr(block, "type", None) == "text":
                reply_text += block.text

        parsed = parse_claude_date_reply(reply_text)
        if parsed is None:
            print(f"{src_path.name}: Claude reply not parseable ({reply_text!r}) -- flagged for review")
            review_rows.append((src_path.name, f"unparseable reply: {reply_text!r}"))
            fail += 1
            save_review_crops(src_path, review_dir)
            continue

        year, month, day = parsed
        date_str = f"{year:04d}-{month:02d}-{day:02d}"
        if update_exif(dest, year, month, day):
            print(f"{src_path.name}: {date_str} -> EXIF updated")
            processed_rows.append((src_path.name, date_str))
            success += 1
        else:
            review_rows.append((src_path.name, "EXIF write failed"))
            fail += 1

    if processed_rows:
        processed_csv = output_folder / "processed_dates.csv"
        # Append rather than overwrite, so re-running step2 against additional
        # batches (or a rerun after fixing review items) doesn't lose earlier records.
        write_header = not processed_csv.exists()
        with open(processed_csv, "a", newline="") as f:
            w = csv.writer(f)
            if write_header:
                w.writerow(["filename", "date_written"])
            w.writerows(processed_rows)
        print(f"\n{len(processed_rows)} date(s) written -- full record in {processed_csv}")

    if review_rows:
        review_csv = output_folder / "needs_review.csv"
        with open(review_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["filename", "reason"])
            w.writerows(review_rows)
        print(f"\n{len(review_rows)} image(s) need manual review -- see {review_csv}")
        if review_dir.exists():
            print(f"4 corner-candidate crops for each are saved in {review_dir}/ (suffixed _BR/_BL/_TR/_TL)")

    print(f"\nDone. Updated: {success}, Needs review: {fail}")


if __name__ == "__main__":
    main()
