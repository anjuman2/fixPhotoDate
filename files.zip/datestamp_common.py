#!/usr/bin/env python3
"""
datestamp_common.py

Locates which corner of a scanned photo the orange/red LED date stamp is
in. Scans in this library have turned up several different orientations
for the same physical stamp depending on how the negative/print was fed
into the scanner:

    - normal:                    date bottom-right, reads normally
    - mirrored:                  date bottom-left, mirrored left-right
    - relocated (portrait scan): date top-right, reads normally
    - relocated + mirrored:      date top-left, mirrored left-right
    - rotated 180 degrees:       date top-left (or elsewhere), upside-down

That's not an exhaustive list -- there's no guarantee some other batch
won't turn up yet another combination. Two earlier approaches both proved
too brittle for this:
  1. Pixel-color localization (find orange pixels, cluster into a bounding
     box) breaks down whenever the background near the stamp is also
     warm-toned (wood furniture, skin, etc. -- confirmed on real photos
     where 70% of an entire corner crop was "orange" by color threshold).
  2. Pre-flipping specific corners in code to "undo" the mirroring assumes
     we've correctly enumerated every orientation in advance -- and then a
     180-degree-rotated batch showed up that neither of our two flip rules
     covered.

So this version does the minimum on our end: crop all 4 corners, raw and
unmodified, and hand all 4 to Claude in a single request along with an
explanation that the stamp (wherever it is) might be normal, mirrored,
upside-down, or both. Claude's vision can mentally correct for that the
same way a person could read an upside-down clock -- we don't need to
pre-guess the transform in code.
"""

import io
import re
import base64
from pathlib import Path

import piexif
from PIL import Image

# Fraction of the image's width/height used for each corner candidate crop.
CROP_W_FRAC = 0.32
CROP_H_FRAC = 0.24

CORNERS = ["BR", "BL", "TR", "TL"]
CORNER_LABELS = {
    "BR": "A (bottom-right, as scanned, no correction applied)",
    "BL": "B (bottom-left, as scanned, no correction applied)",
    "TR": "C (top-right, as scanned, no correction applied)",
    "TL": "D (top-left, as scanned, no correction applied)",
}


def _get_corner_crop(im, corner, cw, ch):
    w, h = im.size
    if corner == "BR":
        box = (w - cw, h - ch, w, h)
    elif corner == "BL":
        box = (0, h - ch, cw, h)
    elif corner == "TR":
        box = (w - cw, 0, w, ch)
    elif corner == "TL":
        box = (0, 0, cw, ch)
    else:
        raise ValueError(corner)
    return im.crop(box)


def get_all_corner_crops(image_path):
    """
    Returns an ordered list of (corner_code, PIL.Image) for all 4 corners,
    raw and unmodified -- no flipping or rotating. Claude is told in the
    prompt that whichever corner has the stamp may need mental correction
    for mirroring and/or upside-down rotation.
    """
    im = Image.open(image_path).convert("RGB")
    w, h = im.size
    cw, ch = int(w * CROP_W_FRAC), int(h * CROP_H_FRAC)
    return [(corner, _get_corner_crop(im, corner, cw, ch)) for corner in CORNERS]


def crop_to_base64_jpeg(crop_img, target_max_dim=1300):
    """
    Normalize every crop to roughly the same size before sending to Claude,
    regardless of the source scan's resolution. Small crops (from small scans)
    get upscaled so fine LED segments are visible; large crops (from high-res
    scans) get downscaled so we're not paying to ship a multi-megabyte image
    for a tiny text stamp. Without this, a 6000x4000 source image produces a
    corner crop alone bigger than several of the small scans combined.
    """
    longest_side = max(crop_img.width, crop_img.height)
    scale = target_max_dim / longest_side
    new_size = (max(1, round(crop_img.width * scale)), max(1, round(crop_img.height * scale)))
    resized = crop_img.resize(new_size, Image.LANCZOS)
    buf = io.BytesIO()
    resized.convert("RGB").save(buf, format="JPEG", quality=90)
    return base64.standard_b64encode(buf.getvalue()).decode("utf-8")


def update_exif(image_path, year, month, day):
    """
    Write DateTimeOriginal/DateTimeDigitized into the image's EXIF, in
    whichever way that image format actually supports.

    JPEG goes through piexif, which handles a lot of quirky real-world EXIF
    edge cases well. TIFF goes through Pillow's own Exif object instead --
    piexif.insert() only supports JPEG under the hood and fails silently on
    TIFF with a blank-message exception (InvalidImageDataError with no
    text), and piexif's own loader can also choke reading certain TIFF-
    specific tags (e.g. some scanner MakerNote blobs) that Pillow reads
    without issue. Confirmed against a real Plustek/SilverFast TIFF scan.
    """
    image_path = Path(image_path)
    date_str = f"{year:04d}:{month:02d}:{day:02d} 12:00:00"
    suffix = image_path.suffix.lower()

    if suffix in (".tif", ".tiff"):
        try:
            im = Image.open(image_path)
            exif = im.getexif()
            EXIF_IFD_TAG = 0x8769
            DATETIME_ORIGINAL = 0x9003
            DATETIME_DIGITIZED = 0x9004
            exif_ifd = exif.get_ifd(EXIF_IFD_TAG)
            exif_ifd[DATETIME_ORIGINAL] = date_str
            exif_ifd[DATETIME_DIGITIZED] = date_str
            exif[EXIF_IFD_TAG] = exif_ifd
            im.save(image_path, format="TIFF", exif=exif)
            return True
        except Exception as e:
            print(f"    EXIF write failed (TIFF): {e!r}")
            return False

    try:
        try:
            exif_dict = piexif.load(str(image_path))
        except Exception:
            exif_dict = {"0th": {}, "Exif": {}, "GPS": {}, "1st": {}, "thumbnail": None}
        exif_dict["Exif"][piexif.ExifIFD.DateTimeOriginal] = date_str.encode("utf-8")
        exif_dict["Exif"][piexif.ExifIFD.DateTimeDigitized] = date_str.encode("utf-8")
        exif_bytes = piexif.dump(exif_dict)
        piexif.insert(exif_bytes, str(image_path))
        return True
    except Exception as e:
        print(f"    EXIF write failed: {e!r}")
        return False


def parse_claude_date_reply(text):
    """
    Expects Claude to reply with exactly 'MM=<n> DD=<n> YY=<n>' (in any
    order -- we look up by label, not position) or 'UNKNOWN'. Returns
    (year, month, day) or None.
    """
    text = (text or "").strip()
    if not text or text.upper() == "UNKNOWN":
        return None

    values = {}
    for key in ("MM", "DD", "YY"):
        m = re.search(rf"{key}\s*=\s*(\d{{1,2}})", text, re.IGNORECASE)
        if not m:
            return None
        values[key] = int(m.group(1))

    month, day, yy = values["MM"], values["DD"], values["YY"]
    if not (1 <= month <= 12 and 1 <= day <= 31 and 0 <= yy <= 99):
        return None
    year = 1900 + yy if yy >= 50 else 2000 + yy
    return (year, month, day)


CLAUDE_PROMPT = (
    "These are the four corners of a scanned 35mm film photo, labeled A "
    "(bottom-right), B (bottom-left), C (top-right), and D (top-left), each "
    "shown exactly as scanned with no correction applied. Exactly one of "
    "these four corners contains a small orange or red digital date stamp "
    "printed by the camera, in the format MMDD'YY (month, day, apostrophe, "
    "2-digit year). The other three corners will just show background "
    "(wall, furniture, wood grain, etc.) with no date stamp -- ignore any "
    "warm/orange-toned wood, skin tone, or similar background color, and "
    "look specifically for a stamp made of small blocky LED/LCD-style "
    "digit segments.\n\n"
    "IMPORTANT: because of how these particular negatives were scanned, the "
    "stamp itself may appear in any of these ways in the crop:\n"
    "  - normal and right-reading\n"
    "  - mirrored left-right (a horizontal flip)\n"
    "  - upside-down (rotated 180 degrees)\n"
    "  - both mirrored AND upside-down\n"
    "Mentally correct for whichever of these applies -- the same way you'd "
    "read an upside-down or mirrored clock face -- and report the TRUE "
    "digit sequence as the camera printed it, not as it visually appears in "
    "the crop.\n\n"
    "The day may be ONE or TWO digits (not zero-padded when single-digit) "
    "-- e.g. \"10 9'00\" is October 9, 2000, and \"1019'96\" is October 19, "
    "1996. Read carefully: do not drop a digit from a 2-digit day.\n\n"
    "Find the one corner with the actual stamp and read its digits exactly "
    "as the camera printed them (after correcting for mirroring/rotation). "
    "Respond with ONLY this exact format, filling in the numbers you read:\n"
    "MM=<number> DD=<number> YY=<number>\n\n"
    "For example: MM=10 DD=19 YY=96\n\n"
    "If none of the four corners has a readable date stamp, respond with "
    "exactly: UNKNOWN\n\n"
    "Do not include any other words, punctuation, letter labels, or "
    "explanation -- just that one line, or UNKNOWN."
)

